using UnityEngine;
public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;
    private Rigidbody2D body;
    private Animator anim;
    private bool isJumping;
    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }
    private void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        // �������������� ������������
        body.linearVelocity = new Vector2(horizontalInput * speed, body.linearVelocity.y);
        anim.SetBool("Move", horizontalInput != 0);
        if (horizontalInput > 0.01f)
            {
                transform.localScale = new Vector3(0.776f, 0.776f, 0.776f);
            }
        else if (horizontalInput < -0.01f)
            {
                transform.localScale = new Vector3(-0.776f, 0.776f, 0.776f);
            }
        // ������
        if (Input.GetKeyDown(KeyCode.X) && isJumping == false)
        {
            body.linearVelocity = new Vector2(body.linearVelocity.x, jumpForce);
            anim.SetBool("Jump", true);
        }
        // �������� ������ � �������
        if (body.linearVelocity.y > 0.1f)
        {
            anim.SetBool("Jump", true);
            anim.SetBool("Fall", false);
        }
        else if (body.linearVelocity.y < -0.1f)
        {
            anim.SetBool("Jump", false);
            anim.SetBool("Fall", true);
        }
    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Firm_ground"))
        {
            isJumping=false;
            anim.SetBool("Jump", false);
            anim.SetBool("Fall", false);
    }
    }
    private void OnCollisionExit2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Firm_ground"))
        {
            isJumping=true;
        }
    }
}